import React from 'react'
import Common from './Common'
import img from "./img/workforce-organization-management_335657-3158.jpg"
const Contract=()=>{
    return(
        <>
   <Common
         img={img}
        text='welcome to Contract Page'
        visit='/services'
        btn="know more"
   />
             
        </>
    )
} 
export default  Contract
