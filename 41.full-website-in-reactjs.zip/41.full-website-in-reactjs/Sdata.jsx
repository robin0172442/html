
import Img1 from "./img/img1.jpg"
import img2 from "./img/img2.jpg"
import img3 from "./img/img5.png"
import img4 from "./img/img6.jpg"

const Sdata=[//this is a array of and object
        {
            imgsrc:Img1,
            title:"Web-development"
        },
        {
            imgsrc:img2,
            title:"SEO"
        },
        {
            imgsrc:img3,
            title:"marketing"
        },
        {
            imgsrc:img4,
            title:"Backend"
        },
    
    ]

    export default Sdata;

